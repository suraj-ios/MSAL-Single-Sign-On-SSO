//
//  SuccessfulViewController.swift
//  SingleSignOnDemoApp
//
//  Created by Suraj on 20/01/24.
//

import UIKit

class SuccessfulViewController: UIViewController {

    @IBOutlet weak var lblTitle: UILabel!
    var authToekn:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.lblTitle.text = authToekn
    }
    
}
