#  SSO Using MSAL

1.https://github.com/AzureAD/microsoft-authentication-library-for-objc
2.Create new account/login using existing account
3.Register a new Application
4.https://github.com/Azure-Samples/ms-identity-mobile-apple-swift-objc
5.Redirect URL formate - 
    msauth.$(PRODUCT_BUNDLE_IDENTIFIER)://auth
    msauth.<app_bundle_id>://auth

For example :- 
    msauth.com.ios.SingleSignOn.Jan2024://auth

#info.plist

    <key>CFBundleURLTypes</key>
    <array>
        <dict>
            <key>CFBundleURLSchemes</key>
            <array>
                <string>msauth.com.ios.SingleSignOn.Jan2024</string>
                <string>42d070bd-c6a0-4549-8e9f-f72f6ad43cdf</string>
            </array>
        </dict>
    </array>
    <key>LSApplicationQueriesSchemes</key>
    <array>
        <string>msauth</string>
        <string>msauthv2</string>
        <string>msauthv3</string>
    </array>
    
    
# Default app's access group: "Masked(not-null)"
-> Complete Code is not getting call, Like In didload need to configure init func for MSAL and Graph API should call on Button click and rest function just do copy and paste.


# MSALErrorDescriptionKey=The request is not valid for the application's 'userAudience' configuration. In order to use /common/ endpoint, the application must not be configured with 'Consumer' as the user audience. The userAudience should be configured with 'All' to use /common/ endpoint.
-> https://stackoverflow.com/questions/63924098/is4-request-not-valid-for-the-applications-useraudience-configuration
-> Go to the manifest section in the sidebar of your app on portal.azure.com, change the value of "signInAudience": "PersonalMicrosoftAccount" to "signInAudience": "AzureADandPersonalMicrosoftAccount" in the JSON there and save.

